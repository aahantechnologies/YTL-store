<!DOCTYPE html>
<?php
include 'connection.php' ;
$pcode = $_REQUEST['pid'];
$query="select * from productdetail where pcode='$pcode'";         
$res=mysqli_query($con,$query);         
$row5=mysqli_fetch_array($res);
$cat = $row5['category'];
// $chekkk = "select * from categories where id='$cat'";
// $resf=mysqli_query($con,$chekkk);         
// $rowf=mysqli_fetch_array($resf);

?>
<html lang="zxx">

<head>
     <meta charset="UTF-8">
    <meta name="description" content="YTL Store">
    <meta name="keywords" content="YTL Store">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>YTL | Store</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
<style>
    .noproduct{
        text-align: center;
        color: #fa7e00;
        margin: 0 auto;
    }
   .mybtnsize {
    background: #fa7e01;
    border: 1px solid #fa7e01;
    padding: 3px 9px;
    color: white;
}
    
</style>
</head>

<body>
    <!-- Page Preloder -->
    <?php
    include 'Header.php';
    ?>
    <!-- Header Section End -->

   <?php
   include 'SubPagesHead.php';
   ?>

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2><?php echo $row5['productname']; ?></h2>
                        <div class="breadcrumb__option">
                            <a href="./index.php">Home</a>
                            <!--<a href="./index.php">Vegetables</a>-->
                            <span><?php echo $row5['productname']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Product Details Section Begin -->
    <section class="product-details spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__pic">
                        <div class="product__details__pic__item">
                            <img class="product__details__pic__item--large"
                                src="../api/<?php echo $row5['image']; ?>" alt="" style="height: 400px; object-fit: contain;">
                        </div>
                        <div class="product__details__pic__slider owl-carousel">
                            <img data-imgbigurl="../api/<?php echo $row5['imagesec']; ?>"
                                src="../api/<?php echo $row5['imagesec']; ?>" alt="">
                            <img data-imgbigurl="../api/<?php echo $row5['imagethird']; ?>"
                                src="../api/<?php echo $row5['imagethird']; ?>" alt="">
                            <img data-imgbigurl="../api/<?php echo $row5['imagelast']; ?>"
                                src="../api/<?php echo $row5['imagelast']; ?>" alt="">
                            <img data-imgbigurl="../api/<?php echo $row5['image']; ?>"
                                src="../api/<?php echo $row5['image']; ?>" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__text">
                        <h3><?php echo $row5['productname']; ?></h3>
                        <div class="product__details__rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                            <span>(18 reviews)</span>
                        </div>
                        <div class="product__details__price">Rs. <span id="realpricego"><?php echo $row5['offerprice']; ?></span></div>
                        <p><?php echo $row5['description']; ?>.</p>
                        <p>
                        <?php
                        if($row5['gosize']==''){
                        }else{
                        ?>
                        <input class="mybtnsize c<?php echo $row5['gosize']; ?>" onClick="myFunc('<?php echo $row5['offerprice']; ?>','<?php echo $row5['gosize']; ?>');" type="submit" value="<?php echo $row5['gosize']; ?>"  /> 
                        <?php
                        }if($row5['gosize1']==''){
                        }else{
                        ?>
                        <input class="mybtnsize c<?php echo $row5['gosize1']; ?>" onClick="myFunc('<?php echo $row5['offerprice1']; ?>','<?php echo $row5['gosize1']; ?>');" type="submit" value="<?php echo $row5['gosize1']; ?>"  />
                        <?php
                        }if($row5['gosize2']==''){
                        }else{
                        ?>
                        <input class="mybtnsize c<?php echo $row5['gosize2']; ?>" onClick="myFunc('<?php echo $row5['offerprice2']; ?>');" type="submit" value="<?php echo $row5['gosize2']; ?>"  />
                        <?php
                        }if($row5['gosize3']==''){
                        }else{
                        ?>
                        <input class="mybtnsize c<?php echo $row5['gosize3']; ?>" onClick="myFunc('<?php echo $row5['offerprice3']; ?>');" type="submit" value="<?php echo $row5['gosize3']; ?>"  />
                        <?php
                        }if($row5['gosize4']==''){
                        }else{
                        ?>
                        <input class="mybtnsize c<?php echo $row5['gosize4']; ?>" onClick="myFunc('<?php echo $row5['offerprice4']; ?>');" type="submit" value="<?php echo $row5['gosize4']; ?>"  />
                        <?php
                        }
                        ?>
                        </p>
                        <div class="product__details__quantity">
                            <div class="quantity">
                                <div class="pro-qty">
                                    <input type="text" value="1">
                                </div>
                            </div>
                        </div>
                         <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                              <a href="AddOrderCode.php?addcartitem=<?php echo $row5['regid']; ?>" class="primary-btn">ADD TO CARD</a>
                                                  <?php  
                                                }else{
                                                ?>
                                              <a href="Login.php" onclick="alert('Login First');" class="primary-btn">ADD TO CARD</a>
                                              <?php
                                                }
                                                ?>
                        <!--<a href="#" class="heart-icon"><span class="icon_heart_alt"></span></a>-->
                        <ul>
                            <li><b>Availability</b> <span>In Stock</span></li>
                            <li><b>Shipping</b> <span>01 day shipping. <samp>Free pickup today</samp></span></li>
                            <li><b>Weight</b> <span id="mysizego"><?php echo $row5['gosize']; ?></span></li>
                            <li><b>Share on</b>
                                <div class="share">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-pinterest"></i></a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="product__details__tab">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab"
                                    aria-selected="true">Description</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab"
                                    aria-selected="false">Information</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab"
                                    aria-selected="false">Reviews <span>(1)</span></a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="tabs-1" role="tabpanel">
                                <div class="product__details__tab__desc">
                                    <h6>Products Description</h6>
                                    <p><?php echo $row5['description']; ?>.</p>
                                </div>
                            </div>
                            <div class="tab-pane" id="tabs-2" role="tabpanel">
                                <div class="product__details__tab__desc">
                                    <h6>Products Infomation</h6>
                                    <p><?php echo $row5['information']; ?>.</p>
                                </div>
                            </div>
                            <div class="tab-pane" id="tabs-3" role="tabpanel">
                                <div class="product__details__tab__desc">
                                    <h6>Products Reviews</h6>
                                    <p><?php echo $row5['metadescription']; ?>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product Details Section End -->

    <!-- Related Product Section Begin -->
    <section class="related-product">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title related__product__title">
                        <h2>Related Product</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                 <?php
                  $queryj="select * from productdetail where category='$cat' and pcode!='$pcode' LIMIT 4"; 
                  $resj=mysqli_query($con,$queryj); 
                   $num=mysqli_num_rows($resj);
                   if($num>0){ 
                  while($row=mysqli_fetch_array($resj)){         
                  ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="product__item">
                        <div class="product__item__pic set-bg">
                             <img src="../api/<?php echo $row['image']; ?>" style="height: 200px;width: 170px; text-align: center;margin: 0 46px;;padding: 15px 0 0 0;">
                            <ul class="product__item__pic__hover">
                             <li><a href="shop-details.php?pid=<?php echo $row['pcode'];?>"><i class="fa fa-eye"></i></a></li>
                             <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                             <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                           </ul>
                        </div>
                         <div class="product__item__text">
                           <h6><a href="#"><?php echo $row['productname'];?></a></h6>
                            <h5>Rs.<?php echo $row['offerprice'];?>.00</h5>
                         </div>
                    </div>
                </div>
                 <?php
                  }
                  }else{
                  ?>
                  <h5 class="noproduct">No Product Found</h5>
                  <?php
                  }
                  ?>
                <!--<div class="col-lg-3 col-md-4 col-sm-6">-->
                <!--    <div class="product__item">-->
                <!--        <div class="product__item__pic set-bg" data-setbg="img/product/product-2.jpg">-->
                <!--            <ul class="product__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="product__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6">-->
                <!--    <div class="product__item">-->
                <!--        <div class="product__item__pic set-bg" data-setbg="img/product/product-3.jpg">-->
                <!--            <ul class="product__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="product__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6">-->
                <!--    <div class="product__item">-->
                <!--        <div class="product__item__pic set-bg" data-setbg="img/product/product-7.jpg">-->
                <!--            <ul class="product__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="product__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>
    <!-- Related Product Section End -->

    <!-- Footer Section Begin -->
   
    <?php
    include 'Footer.php';
    ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
<script>
   function myFunc(id,sizego){
        // alert(sizego);
       
         document.getElementById("realpricego").innerHTML = id;
         document.getElementById("mysizego").innerHTML = sizego;
}
    $(".c<?php echo $row5['gosize']; ?>").click(function(){
         $('.c<?php echo $row5['gosize']; ?>').css('background', '#FFC107'); 
         $('.c<?php echo $row5['gosize1']; ?>').css('background', '#fa7e00'); 
         $('.c<?php echo $row5['gosize2']; ?>').css('background', '#fa7e00'); 
         $('.c<?php echo $row5['gosize3']; ?>').css('background', '#fa7e00'); 
        });
        $(".c<?php echo $row5['gosize1']; ?>").click(function(){
         $('.c<?php echo $row5['gosize']; ?>').css('background', '#fa7e00');
         $('.c<?php echo $row5['gosize1']; ?>').css('background', '#FFC107'); 
         $('.c<?php echo $row5['gosize2']; ?>').css('background', '#fa7e00'); 
         $('.c<?php echo $row5['gosize3']; ?>').css('background', '#fa7e00');  
        });
         $(".c<?php echo $row5['gosize2']; ?>").click(function(){
         $('.c<?php echo $row5['gosize']; ?>').css('background', '#fa7e00');
         $('.c<?php echo $row5['gosize1']; ?>').css('background', '#fa7e00'); 
         $('.c<?php echo $row5['gosize2']; ?>').css('background', '#FFC107'); 
         $('.c<?php echo $row5['gosize3']; ?>').css('background', '#fa7e00'); 
         });
         $(".c<?php echo $row5['gosize3']; ?>").click(function(){
         $('.c<?php echo $row5['gosize']; ?>').css('background', '#fa7e00');
         $('.c<?php echo $row5['gosize1']; ?>').css('background', '#fa7e00'); 
         $('.c<?php echo $row5['gosize2']; ?>').css('background', '#fa7e00'); 
         $('.c<?php echo $row5['gosize3']; ?>').css('background', '#FFC107'); 
         });
$(document).ready(function(){
 
    // Get value on button click and show alert
    $("#myBtn").click(function(){
        var str = $("#myBtn").val();
        alert(str);
    });
});
</script>

</body>

</html>