<?php
if(empty($_SESSION)) {
  session_start();
}
?>

<!DOCTYPE html>
<?php
    include 'connection.php';
    ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" />
    <!-- Main css -->
    <link rel="stylesheet" href="css/Login.css">
</head>
<body>

    <div class="main">

        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="img/signin/signin-image.jpg" alt="sing up image"></figure>
                        <a href="SignUp.php" class="signup-image-link">Create an account</a>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Sign In</h2>
                        <form method="POST" class="register-form" id="login-form">
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="mobile" id="your_name" placeholder="Your Mobile"/>
                            </div>
                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="your_pass" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="login" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="LoginForm/vendor/jquery/jquery.min.js"></script>
    <script src="LoginForm/js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
<?php
if(isset($_REQUEST['login']))
{
  $mobile=$_REQUEST['mobile'];
  $password=$_REQUEST['password'];
  $query="select * from userregister where phonenumber='$mobile' and password='$password'";
  $res=mysqli_query($con,$query);
  $row=mysqli_fetch_array($res);
  $num=mysqli_num_rows($res);
  if($num>0):
      $_SESSION['ytlusercode'] = $row['uid'];
  	echo "<script>window.location='index.php'</script>";
// echo $row['uid'];
  else:
  	echo "<script>alert('Login failed....')</script>";
  	echo "<script>window.location='Login.php'</script>";
  endif;
}
?>