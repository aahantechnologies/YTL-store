<?php
// @ob_start();
if(empty($_SESSION)) {
  session_start();
}
// echo session_id();
?>
<?php
include 'connection.php'; 
if(isset($_REQUEST['addcartitem']))
{
  $regid=$_REQUEST['addcartitem'];
  $check = "select * from productdetail where regid='$regid'";
  $res = mysqli_query($con,$check);
  $row = mysqli_fetch_array($res);
		 $productname = $row['productname'];
		 $category = $row['category'];
		 $subcategory = $row['subcategory'];
		 $description = $row['description'];
		 $realprice = $row['realprice'];
		 $offerprice = $row['offerprice'];
		 $quantity = $row['quantity'];
		 $vendorprice = $row['vendorprice'];
		 $vendorquantity = $row['vendorquantity'];
		 $destination = $row['image'];
		 $destination2 = $row['imagesec'];
		 $destination4 = $row['imagethird'];
		 $destination6 = $row['imagelast'];
		 $gosize = $row['gosize'];
		 $newcade = $row['pcode'];
		 $brand = $row['brand'];
		 $tdemail = $_SESSION['ytlusercode'];
		 
		 
$firstname = mysqli_real_escape_string($con, $description);
 $querydata="insert into orderdetail values (NULL,'$tdemail','$productname','$category','$subcategory','$firstname', '$gosize','$realprice','$offerprice','$quantity','$vendorprice','$vendorquantity','$destination','$destination2','$destination4','$destination6','$brand','$newcade','0', now())";
   
$resultdata = mysqli_query($con ,$querydata); 
if($resultdata){
  	echo "<script>window.location='shoping-cart.php'</script>";
// echo $row['uid'];
}
  else{
  	echo "<script>alert('Error....')</script>";
  	echo "<script>window.location='shoping-cart.php'</script>";
  }
}
?>