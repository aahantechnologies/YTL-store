<!DOCTYPE html>
<?php
session_start();
    include 'connection.php';
    ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up </title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" />
    <!-- Main css -->
    <link rel="stylesheet" href="css/Login.css">
</head>
<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Sign up</h2>
                        <form method="POST" class="register-form" id="register-form">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-phone"></i></label>
                                <input type="tel" name="phonenumber" id="mobile" placeholder="Your Mobile"/>
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="pass" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="repassword" id="re_pass" placeholder="Repeat your password"/>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="signup" id="signup" class="form-submit" value="Register"/>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="img/signin/signup-image.jpg" alt="sing up image"></figure>
                        <a href="Login.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="LoginForm/vendor/jquery/jquery.min.js"></script>
    <script src="LoginForm/js/main.js"></script>
</body>
</html>

<?php
if(isset($_REQUEST['signup']))
{
  extract($_REQUEST);  
  if($password!=$repassword){
      echo "<script>alert('Password do not match')</script>";
  }else{
  $check = "select * from userregister where phonenumber='$phonenumber'";
  $result=mysqli_query($con,$check);
  $num=mysqli_num_rows($result);
 if($num>0){
     echo "<script>alert('This Email Already Exist')</script>";
 }
 else{
    $randomNum = substr(str_shuffle("0123456789"), 0, 8);
    $newcade = 'ytlstore' .$randomNum;
    $query = "insert into userregister values (NULL,'$name','$email','$phonenumber', '$password','','0','$newcade', now())";
    $res=mysqli_query($con,$query);
 if($res)
  {
      $_SESSION['ytlcode'] = $newcade;
  	echo "<script>window.location='index.php'</script>";
  }
 else
 {
  echo "<script>alert('Failed')</script>";
 }
}
}
}
?>