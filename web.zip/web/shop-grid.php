<!DOCTYPE html>
<?php
if(!isset($_REQUEST['cat'])){
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
}
?>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="YTL Store">
    <meta name="keywords" content="YTL Store">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>YTL | Store</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<style>
    .noproduct{
        text-align: center;
        color: #fa7e00;
        margin: 52px auto;
    }
    
    
</style>
<body>
   
    <!-- Page Preloder -->
    <?php
    include 'Header.php';
    ?>
    <!-- Header Section End -->

   <?php
   include 'SubPagesHead.php';
   ?>

    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>YTL Shop</h2>
                        <div class="breadcrumb__option">
                            <a href="./index.php">Home</a>
                            <span>Shop</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Product Section Begin -->
    <section class="product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-5">
                    <div class="sidebar">
                        <div class="sidebar__item">
                            <h4>Categories</h4>
                            <ul>
                                   <?php
                                   $query="select * from categories where parent_id='0'";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                                    
                                   <li><a href="<?php echo $actual_link;?>?cat=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></li>
                                     <?php
                                   }
                                   ?>
                            </ul>
                        </div>
                        <!--<div class="sidebar__item">-->
                        <!--    <h4>Price</h4>-->
                        <!--    <div class="price-range-wrap">-->
                        <!--        <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"-->
                        <!--            data-min="10" data-max="540">-->
                        <!--            <div class="ui-slider-range ui-corner-all ui-widget-header"></div>-->
                        <!--            <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>-->
                        <!--            <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>-->
                        <!--        </div>-->
                        <!--        <div class="range-slider">-->
                        <!--            <div class="price-input">-->
                        <!--                <input type="text" id="minamount">-->
                        <!--                <input type="text" id="maxamount">-->
                        <!--            </div>-->
                        <!--        </div>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <!--<div class="sidebar__item sidebar__item__color--option">-->
                        <!--    <h4>Colors</h4>-->
                        <!--    <div class="sidebar__item__color sidebar__item__color--white">-->
                        <!--        <label for="white">-->
                        <!--            White-->
                        <!--            <input type="radio" id="white">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__color sidebar__item__color--gray">-->
                        <!--        <label for="gray">-->
                        <!--            Gray-->
                        <!--            <input type="radio" id="gray">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__color sidebar__item__color--red">-->
                        <!--        <label for="red">-->
                        <!--            Red-->
                        <!--            <input type="radio" id="red">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__color sidebar__item__color--black">-->
                        <!--        <label for="black">-->
                        <!--            Black-->
                        <!--            <input type="radio" id="black">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__color sidebar__item__color--blue">-->
                        <!--        <label for="blue">-->
                        <!--            Blue-->
                        <!--            <input type="radio" id="blue">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__color sidebar__item__color--green">-->
                        <!--        <label for="green">-->
                        <!--            Green-->
                        <!--            <input type="radio" id="green">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <!--<div class="sidebar__item">-->
                        <!--    <h4>Popular Size</h4>-->
                        <!--    <div class="sidebar__item__size">-->
                        <!--        <label for="large">-->
                        <!--            Large-->
                        <!--            <input type="radio" id="large">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__size">-->
                        <!--        <label for="medium">-->
                        <!--            Medium-->
                        <!--            <input type="radio" id="medium">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__size">-->
                        <!--        <label for="small">-->
                        <!--            Small-->
                        <!--            <input type="radio" id="small">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--    <div class="sidebar__item__size">-->
                        <!--        <label for="tiny">-->
                        <!--            Tiny-->
                        <!--            <input type="radio" id="tiny">-->
                        <!--        </label>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="sidebar__item">
                            <div class="latest-product__text">
                                <h4>Latest Products</h4>
                                <div class="latest-product__slider owl-carousel">
                                    <div class="latest-prdouct__slider__item">
                                         <?php
                                  $queryj="select * from productdetail order by regid DESC LIMIT 3 OFFSET 0"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                        <!--<a href="#" class="latest-product__item">-->
                                        <!--    <div class="latest-product__item__pic">-->
                                        <!--        <img src="img/latest-product/lp-2.jpg" alt="">-->
                                        <!--    </div>-->
                                        <!--    <div class="latest-product__item__text">-->
                                        <!--        <h6>Crab Pool Security</h6>-->
                                        <!--        <span>$30.00</span>-->
                                        <!--    </div>-->
                                        <!--</a>-->
                                        <!--<a href="#" class="latest-product__item">-->
                                        <!--    <div class="latest-product__item__pic">-->
                                        <!--        <img src="img/latest-product/lp-3.jpg" alt="">-->
                                        <!--    </div>-->
                                        <!--    <div class="latest-product__item__text">-->
                                        <!--        <h6>Crab Pool Security</h6>-->
                                        <!--        <span>$30.00</span>-->
                                        <!--    </div>-->
                                        <!--</a>-->
                                    </div>
                                    <div class="latest-prdouct__slider__item">
                                           <?php
                                  $queryj="select * from productdetail order by regid DESC  LIMIT 3 OFFSET 3"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                        <!--<a href="#" class="latest-product__item">-->
                                        <!--    <div class="latest-product__item__pic">-->
                                        <!--        <img src="img/latest-product/lp-2.jpg" alt="">-->
                                        <!--    </div>-->
                                        <!--    <div class="latest-product__item__text">-->
                                        <!--        <h6>Crab Pool Security</h6>-->
                                        <!--        <span>$30.00</span>-->
                                        <!--    </div>-->
                                        <!--</a>-->
                                        <!--<a href="#" class="latest-product__item">-->
                                        <!--    <div class="latest-product__item__pic">-->
                                        <!--        <img src="img/latest-product/lp-3.jpg" alt="">-->
                                        <!--    </div>-->
                                        <!--    <div class="latest-product__item__text">-->
                                        <!--        <h6>Crab Pool Security</h6>-->
                                        <!--        <span>$30.00</span>-->
                                        <!--    </div>-->
                                        <!--</a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-md-7">
                    <!--<div class="filter__item">-->
                    <!--    <div class="row">-->
                    <!--        <div class="col-lg-4 col-md-5">-->
                    <!--            <div class="filter__sort">-->
                    <!--                <span>Sort By</span>-->
                    <!--                <select>-->
                    <!--                    <option value="0">Default</option>-->
                    <!--                    <option value="0">Default</option>-->
                    <!--                </select>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--        <div class="col-lg-4 col-md-4">-->
                    <!--            <div class="filter__found">-->
                    <!--                <h6><span>16</span> Products found</h6>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--        <div class="col-lg-4 col-md-3">-->
                    <!--            <div class="filter__option">-->
                    <!--                <span class="icon_grid-2x2"></span>-->
                    <!--                <span class="icon_ul"></span>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <div class="row">
                         <?php
                         if(isset($_REQUEST['cat'])){
                             $cat = $_REQUEST['cat'];
                                   $query="select * from productdetail where category='$cat'";  
                         }else{
                             $query="select * from productdetail";  
                         }
                                   $res=mysqli_query($con,$query); 
                                   $num=mysqli_num_rows($res);
                                   if($num>0){         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="product__item">
                                <div class="product__item__pic set-bg"  style="background-color: #f4f6fc;">
                                   <img src="../api/<?php echo $row['image']; ?>" style="height: 200px;width: 170px; text-align: center;margin: 0 46px;;padding: 15px 0 0 0;">
                                    <ul class="product__item__pic__hover">
                                        <li><a href="shop-details.php?pid=<?php echo $row['pcode'];?>"><i class="fa fa-eye"></i></a></li>
                                        <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                         <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                    </ul>
                                </div>
                                <div class="product__item__text">
                                    <h6><a href="#"><?php echo $row['productname'];?></a></h6>
                                    <h5>Rs.<?php echo $row['offerprice'];?>.00</h5>
                                </div>
                            </div>
                        </div>
                        <?php
                                   }
                                   }else{
                                   ?>
                                   <h5 class="noproduct">No Product Found</h5>
                                   <?php
                                   }
                                   ?>
                        
                    </div>
                    <div class="product__pagination">
                        <a href="#">1</a>
                        <a href="#">2</a>
                        <a href="#">3</a>
                        <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                    </div>
                    <br/>
                    <br/>
                    <div class="product__discount">
                        <div class="section-title product__discount__title">
                            <h2>Sale Off</h2>
                        </div>
                        <div class="row">
                            <div class="product__discount__slider owl-carousel">
                                <div class="col-lg-4">
                                    <div class="product__discount__item">
                                        <div class="product__discount__item__pic set-bg"
                                            data-setbg="img/product/discount/pd-1.jpg">
                                            <div class="product__discount__percent">-20%</div>
                                            <ul class="product__item__pic__hover">
                                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="product__discount__item__text">
                                            <span>Dried Fruit</span>
                                            <h5><a href="#">Raisin’n’nuts</a></h5>
                                            <div class="product__item__price">$30.00 <span>$36.00</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="product__discount__item">
                                        <div class="product__discount__item__pic set-bg"
                                            data-setbg="img/product/discount/pd-2.jpg">
                                            <div class="product__discount__percent">-20%</div>
                                            <ul class="product__item__pic__hover">
                                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                 <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="product__discount__item__text">
                                            <span>Vegetables</span>
                                            <h5><a href="#">Vegetables’package</a></h5>
                                            <div class="product__item__price">$30.00 <span>$36.00</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="product__discount__item">
                                        <div class="product__discount__item__pic set-bg"
                                            data-setbg="img/product/discount/pd-3.jpg">
                                            <div class="product__discount__percent">-20%</div>
                                            <ul class="product__item__pic__hover">
                                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                 <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="product__discount__item__text">
                                            <span>Dried Fruit</span>
                                            <h5><a href="#">Mixed Fruitss</a></h5>
                                            <div class="product__item__price">$30.00 <span>$36.00</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="product__discount__item">
                                        <div class="product__discount__item__pic set-bg"
                                            data-setbg="img/product/discount/pd-4.jpg">
                                            <div class="product__discount__percent">-20%</div>
                                            <ul class="product__item__pic__hover">
                                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="product__discount__item__text">
                                            <span>Dried Fruit</span>
                                            <h5><a href="#">Raisin’n’nuts</a></h5>
                                            <div class="product__item__price">$30.00 <span>$36.00</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="product__discount__item">
                                        <div class="product__discount__item__pic set-bg"
                                            data-setbg="img/product/discount/pd-5.jpg">
                                            <div class="product__discount__percent">-20%</div>
                                            <ul class="product__item__pic__hover">
                                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="product__discount__item__text">
                                            <span>Dried Fruit</span>
                                            <h5><a href="#">Raisin’n’nuts</a></h5>
                                            <div class="product__item__price">$30.00 <span>$36.00</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="product__discount__item">
                                        <div class="product__discount__item__pic set-bg"
                                            data-setbg="img/product/discount/pd-6.jpg">
                                            <div class="product__discount__percent">-20%</div>
                                            <ul class="product__item__pic__hover">
                                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="product__discount__item__text">
                                            <span>Dried Fruit</span>
                                            <h5><a href="#">Raisin’n’nuts</a></h5>
                                            <div class="product__item__price">$30.00 <span>$36.00</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product Section End -->

   <?php
   include 'Footer.php';
   ?>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>



</body>

</html>