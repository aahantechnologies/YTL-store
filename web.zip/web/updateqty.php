<?php 
 session_start();
// Include the database config file 
include_once 'connection.php'; 
if(!empty($_POST["cart_id"])){ 
    // Fetch state data based on the specific country  
    $cart_id = $_POST["cart_id"];
    $servicetype = $_POST['new_quantity'];
    // $address ='07:00 a.m. to 07:45 a.m.';
$sql = "update orderdetail set quantity='$servicetype' where regid='$cart_id'";
if ($con->query($sql) === TRUE) {
} else {
}
   
}
?>