
<?php
// @ob_start();
if(empty($_SESSION)) {
  session_start();
}
// echo session_id();
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="YTL Store">
    <meta name="keywords" content="YTL Store">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>YTL | Store</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet" type="text/css">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>
.mySlides {display:none;
    width:100% ;height: 395px;
}
@media only screen and (max-width: 600px) {
.mySlides{
    height: 205px !important;
    margin: 0 0 -42px 0;
}
}
</style>
</head>

<body>
   <?php
   include 'Header.php';
   ?>

    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>All categories</span>
                        </div>
                        <ul>
                            <?php
                            include 'connection.php' ;
                                   $query="select * from categories where parent_id='0'";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                                    
                                   <li><a href="shop-grid.php?cat=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></li>
                                     <?php
                                   }
                                   ?>
                            <!--<li><a href="#">Fresh Meat</a></li>-->
                            <!--<li><a href="#">Vegetables</a></li>-->
                            <!--<li><a href="#">Fruit & Nut Gifts</a></li>-->
                            <!--<li><a href="#">Fresh Berries</a></li>-->
                            <!--<li><a href="#">Ocean Foods</a></li>-->
                            <!--<li><a href="#">Butter & Eggs</a></li>-->
                            <!--<li><a href="#">Fastfood</a></li>-->
                            <!--<li><a href="#">Fresh Onion</a></li>-->
                            <!--<li><a href="#">Papayaya & Crisps</a></li>-->
                            <!--<li><a href="#">Oatmeal</a></li>-->
                            <!--<li><a href="#">Fresh Bananas</a></li>-->
                        </ul>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="#">
                                <!--<div class="hero__search__categories">-->
                                <!--    All Categories-->
                                <!--    <span class="arrow_carrot-down"></span>-->
                                <!--</div>-->
                                <input type="text" placeholder="What do yo u need?">
                                <button type="submit" class="site-btn">SEARCH</button>
                            </form>
                        </div>
                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+65 11.188.888</h5>
                                <span>support 24/7 time</span>
                            </div>
                        </div>
                    </div>
                    <?php
                                   $homeimg="SELECT * FROM homepagebanner";         
                                   $resig=mysqli_query($con,$homeimg);         
                                   $rowimg=mysqli_fetch_array($resig);
                                   ?>
                    <!--<div class="hero__item set-bg" data-setbg="img/hero/banner.jpg">-->
                         <!--<div class="hero__item set-bg" data-setbg="../api/<?php // echo $rowimg['imagesec']; ?>">-->
                    <!--    <div class="hero__text">-->
                    <!--        <span>FRUIT FRESH</span>-->
                    <!--        <h2>Vegetable <br />100% Organic</h2>-->
                    <!--        <p>Free Pickup and Delivery Available</p>-->
                    <!--        <a href="shop-grid.php" class="primary-btn">SHOP NOW</a>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <div class="w3-content w3-section">
                  <img class="mySlides w3-animate-top" src="../api/<?php echo $rowimg['image']; ?>" style="">
                  <img class="mySlides w3-animate-bottom" src="../api/<?php echo $rowimg['imagesec']; ?>" style="">
                  <img class="mySlides w3-animate-top" src="../api/<?php echo $rowimg['imagethird']; ?>" style="">
                  <img class="mySlides w3-animate-bottom" src="../api/<?php echo $rowimg['imageforth']; ?>" style="">
                  <img class="mySlides w3-animate-top" src="../api/<?php echo $rowimg['imagefifth']; ?>" style="">
                  <img class="mySlides w3-animate-bottom" src="../api/<?php echo $rowimg['imagelast']; ?>" style="">
                </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Categories Section Begin -->
    <section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                               <?php
                                   $query="select * from categories where parent_id='0'";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                      <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="" style="background-color: #f4f6fc;">
                            <img src="../api/<?php echo $row['image']; ?>" style="height: 170px;width: 170px; text-align: center; margin: 25px auto;padding: 15px 0 0 0;">
                            <h5><a href="shop-grid.php?cat=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></h5>
                        </div>
                    </div>
                    <?php
                                   }
                                   ?>
                    <!--<div class="col-lg-3">-->
                    <!--    <div class="categories__item set-bg" data-setbg="img/categories/cat-2.jpg">-->
                    <!--        <h5><a href="#">Dried Fruit</a></h5>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3">-->
                    <!--    <div class="categories__item set-bg" data-setbg="img/categories/cat-3.jpg">-->
                    <!--        <h5><a href="#">Vegetables</a></h5>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3">-->
                    <!--    <div class="categories__item set-bg" data-setbg="img/categories/cat-4.jpg">-->
                    <!--        <h5><a href="#">drink fruits</a></h5>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-3">-->
                    <!--    <div class="categories__item set-bg" data-setbg="img/categories/cat-5.jpg">-->
                    <!--        <h5><a href="#">drink fruits</a></h5>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
                
            </div>
        </div>
    </section>
    <!-- Categories Section End -->

    <!-- Featured Section Begin -->
    <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Featured Product</h2>
                    </div>
                    <div class="featured__controls">
                        <ul>
                            <li class="active" data-filter="*">All</li>
                            <li data-filter=".oranges">Grocery & Staples</li>
                            <li data-filter=".fresh-meat">Personal Care</li>
                            <li data-filter=".vegetables">Dairy & Bread</li>
                            <li data-filter=".fastfood">Snacks</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row featured__filter">
                <?php
                                   $query="select * from productdetail where category='36' LIMIT 4";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                                   <div class="col-lg-3 col-md-4 col-sm-6 mix oranges">
                                    <div class="featured__item">
                                       <div class="featured__item__pic set-bg" data-setbg="" style="background-color: #f4f6fc;">
                                          <img src="../api/<?php echo $row['image']; ?>" style="height: 170px;width: 170px; text-align: center;margin: 0 46px;;padding: 15px 0 0 0;">
                                            <ul class="featured__item__pic__hover">
                                                <li><a href="shop-details.php?pid=<?php echo $row['pcode'];?>"><i class="fa fa-eye"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                 <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="featured__item__text">
                                            <h6><a href="#"><?php echo $row['productname'];?></a></h6>
                                            <h5>Rs.<?php echo $row['offerprice'];?>.00</h5>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php
                                
                                   }
                                   ?>
                                   <?php
                                   $query="select * from productdetail where category='7' LIMIT 4";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                                   <div class="col-lg-3 col-md-4 col-sm-6 mix vegetables">
                                    <div class="featured__item">
                                        <div class="featured__item__pic set-bg" data-setbg="" style="background-color: #f4f6fc;">
                                          <img src="../api/<?php echo $row['image']; ?>" style="height: 170px;width: 170px; text-align: center;margin: 0 46px;;padding: 15px 0 0 0;">
                                            <ul class="featured__item__pic__hover">
                                                <li><a href="shop-details.php?pid=<?php echo $row['pcode'];?> "><i class="fa fa-eye"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                  <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="featured__item__text">
                                            <h6><a href="#"><?php echo $row['productname'];?></a></h6>
                                            <h5>Rs.<?php echo $row['offerprice'];?>.00</h5>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php
                                   }
                                   ?>
                                   <?php
                                   $query="select * from productdetail where category='5' LIMIT 4";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                                   <div class="col-lg-3 col-md-4 col-sm-6 mix fresh-meat">
                                
                                    <div class="featured__item">
                                       <div class="featured__item__pic set-bg" data-setbg="" style="background-color: #f4f6fc;">
                                        <img src="../api/<?php echo $row['image']; ?>" style="height: 170px;width: 170px; text-align: center;margin: 0 46px;;padding: 15px 0 0 0;">
                                            <ul class="featured__item__pic__hover">
                                                <li><a href="shop-details.php?pid=<?php echo $row['pcode'];?> "><i class="fa fa-eye"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="featured__item__text">
                                            <h6><a href="#"><?php echo $row['productname'];?></a></h6>
                                            <h5>Rs.<?php echo $row['offerprice'];?>.00</h5>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php
                                   }
                                   ?>
                                   <?php
                                   $query="select * from productdetail where category='15' LIMIT 4";         
                                   $res=mysqli_query($con,$query);         
                                   while($row=mysqli_fetch_array($res)){         
                                   ?>
                                   <div class="col-lg-3 col-md-4 col-sm-6 mix fastfood">
                                    <div class="featured__item">
                                        <div class="featured__item__pic set-bg" data-setbg="" style="background-color: #f4f6fc;">
                                            <img src="../api/<?php echo $row['image']; ?>" style="height: 170px;width: 170px; text-align: center;margin: 0 46px;;padding: 15px 0 0 0;">
                          
                                            <ul class="featured__item__pic__hover">
                                                <li><a href="shop-details.php?pid=<?php echo $row['pcode'];?> "><i class="fa fa-eye"></i></a></li>
                                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                                <?php
                                                if(isset($_SESSION['ytlusercode'])){
                                                    ?>
                                                    
                                                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                                  <?php  
                                                }else{
                                                ?>
                                              <!--onclick="alert('I am a popup!');"-->
                                              <li><a href="Login.php" onclick="alert('Login First');"><i class="fa fa-shopping-cart"></i></a></li>
                                              <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                        <div class="featured__item__text">
                                            <h6><a href="#"><?php echo $row['productname'];?></a></h6>
                                            <h5>Rs.<?php echo $row['offerprice'];?>.00</h5>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php
                                   }
                                   ?>
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix oranges fresh-meat">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-1.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix vegetables fastfood">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-2.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix vegetables fresh-meat">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-3.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix fastfood oranges">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-4.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix fresh-meat vegetables">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-5.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix oranges fastfood">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-6.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix fresh-meat vegetables">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-7.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-3 col-md-4 col-sm-6 mix fastfood vegetables">-->
                <!--    <div class="featured__item">-->
                <!--        <div class="featured__item__pic set-bg" data-setbg="img/featured/feature-8.jpg">-->
                <!--            <ul class="featured__item__pic__hover">-->
                <!--                <li><a href="#"><i class="fa fa-heart"></i></a></li>-->
                <!--                <li><a href="#"><i class="fa fa-retweet"></i></a></li>-->
                <!--                  <li><a href="AddOrderCode.php?addcartitem=<?php echo $row['regid']; ?>"><i class="fa fa-shopping-cart"></i></a></li>-->
                <!--            </ul>-->
                <!--        </div>-->
                <!--        <div class="featured__item__text">-->
                <!--            <h6><a href="#">Crab Pool Security</a></h6>-->
                <!--            <h5>$30.00</h5>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>
    <!-- Featured Section End -->

    <!-- Banner Begin -->
    <div class="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="img/banner/banner-1.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="banner__pic">
                        <img src="img/banner/banner-2.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->

    <!-- Latest Product Section Begin -->
    <section class="latest-product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Latest Products</h4>
                       <div class="latest-product__slider owl-carousel">
                                    <div class="latest-prdouct__slider__item">
                                         <?php
                                  $queryj="select * from productdetail order by regid DESC LIMIT 3 OFFSET 0"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                    </div>
                                    <div class="latest-prdouct__slider__item">
                                           <?php
                                  $queryj="select * from productdetail order by regid DESC  LIMIT 3 OFFSET 3"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                    </div>
                                </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Top Rated Products</h4>
                        <div class="latest-product__slider owl-carousel">
                                    <div class="latest-prdouct__slider__item">
                                         <?php
                                  $queryj="select * from productdetail order by regid DESC LIMIT 3 OFFSET 6"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                    </div>
                                    <div class="latest-prdouct__slider__item">
                                           <?php
                                  $queryj="select * from productdetail order by regid DESC  LIMIT 3 OFFSET 9"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                    </div>
                                </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Review Products</h4>
                        <div class="latest-product__slider owl-carousel">
                                    <div class="latest-prdouct__slider__item">
                                         <?php
                                  $queryj="select * from productdetail order by regid DESC LIMIT 3 OFFSET 12"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                    </div>
                                    <div class="latest-prdouct__slider__item">
                                           <?php
                                  $queryj="select * from productdetail order by regid DESC  LIMIT 3 OFFSET 15"; 
                                  $resj=mysqli_query($con,$queryj); 
                                  while($row=mysqli_fetch_array($resj)){         
                             ?>
                                        <a href="shop-details.php?pid=<?php echo $row['pcode']; ?>" class="latest-product__item">
                                            <div class="latest-product__item__pic" style="width: 41%;">
                                                <img src="../api/<?php echo $row['image']; ?>" class="relatedp" alt="" style="object-fit: contain;">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6><?php echo $row['productname'];?></h6>
                                                <span>Rs.<?php echo $row['offerprice'];?>.00</span>
                                            </div>
                                        </a>
                                        <?php
                                          }
                                          ?>
                                    </div>
                                </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Latest Product Section End -->

    <!-- Blog Section Begin -->
    <section class="from-blog spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title from-blog__title">
                        <h2>From The Blog</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="img/blog/blog-1.jpg" alt="">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> May 4,2019</li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="#">Cooking tips make cooking simple</a></h5>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="img/blog/blog-2.jpg" alt="">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> May 4,2019</li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="#">6 ways to prepare breakfast for 30</a></h5>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="img/blog/blog-3.jpg" alt="">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> May 4,2019</li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="#">Visit the clean farm in the US</a></h5>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog Section End -->
    <?php
    include 'Footer.php';
    ?>
    <!-- Js Plugins -->
<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2500);    
}
</script>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
