<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Xceptiion - Location Detail</title>
        <meta name="description" content="Xceptiion - Location Detail">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <script>
          WebFont.load({
            google: {"families":["Montserrat:400,500,600,700","Noto+Sans:400,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
        <!-- Stylesheet -->
        <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
        <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.theme.min.css">
        <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    </head>
   
   <?php 
   include 'connection.php';
   include 'Header.php';
   ?>
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">
            <?php 
            include 'SideMenu.php';
            ?>
                <div class="content-inner">
                    <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Day Slot</h2>
	                                <div>
			                            <ul class="breadcrumb">
			                                <li class="breadcrumb-item"><a href="db-default.html"><i class="ti ti-home"></i></a></li>
			                                <li class="breadcrumb-item active">Day Slot's</li>
			                            </ul>
	                                </div>
	                            </div>
                                <div class="widget-body">
                                        <div class="form-group">
                                            <a href="AddDaySlot.php">
                                            <button type="button" class="btn btn-primary mr-1 mb-2">Add Day Slot</button></a>
                                        </div>
                                 </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>Detail</h4>
                                    </div>
                                    <div class="widget-body">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Time From</th>       
                                                        <th>Time To</th>       
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
<?php
$query1="select * from dayslot";
$res1=mysqli_query($con,$query1);
$i=1;
while($row1=mysqli_fetch_array($res1))
{
?>
                                                    <tr>
                                                        <td><span class="text-primary"><?php echo $i;?></span></td>
                                                        <td><?php echo $row1['timefrom'];?></td>   
                                                         <td><?php echo $row1['timeto'];?></td>   
                                                        <td class="td-actions">
                                                        <a title='update record' href='EditDaySlot.php?id=<?php echo $row1[0];?>'>
                                                        <i class='la la-edit edit'></i> </a>
                                                        <a title='Delete record' href='DaySlot.php?id=<?php echo $row1[0]; ?>' onclick="return confirm('Are you sure you want to delete this item?');">
                                                        <i class='la la-close delete'></i></a>  
                                                        </td>
                                                    </tr>
<?php
$i++;
}
?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->                              
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
                    <!-- Begin Page Footer-->
                   <?php
           include 'Footer.php';
           ?>
                    <!-- End Page Footer -->
                    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
                </div>
            </div>
            <!-- End Page Content -->
        </div>
        <!-- Begin Vendor Js -->
        <script src="assets/vendors/js/base/jquery.min.js"></script>
        <script src="assets/vendors/js/base/core.min.js"></script>
        <!-- End Vendor Js -->
        <!-- Begin Page Vendor Js -->
        <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
        <script src="assets/vendors/js/app/app.min.js"></script>
        <!-- End Page Vendor Js -->
    </body>
</html>

<?php
if(isset($_REQUEST['id']))
{
$id=$_REQUEST['id'];
  $query="delete from dayslot where regid=$id";
  if(mysqli_query($con,$query))
  {
//   echo "<script>confirm('Are you sure...')</script>";
         echo "<script>alert('Record deleted...')</script>";
    echo "<script>window.location='Location.php'</script>";
  }
  else
  {
  	 echo "<script>alert('Record not deleted...')</script>";
  	 echo "<script>window.location='Location.php'</script>";
 }
}

?>