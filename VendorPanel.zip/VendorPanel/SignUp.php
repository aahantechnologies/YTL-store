<!DOCTYPE html>
<?php
include 'connection.php';
session_start();
?>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Vendor Signup- YTLStore</title>
        <meta name="description" content="Vendor Signup - YTLStore">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <script>
          WebFont.load({
            google: {"families":["Montserrat:400,500,600,700","Noto+Sans:400,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
        <!-- Stylesheet -->
        <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
        <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5.min.css">
        <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    </head>
    <body class="bg-fixed-02">
        <!-- Begin Preloader -->
        <div id="preloader">
            <div class="canvas">
                <div style="color:green;font-size: 3.6em;">YTLStore</div>
                <div class="spinner"></div>   
            </div>
        </div>
        <!-- End Preloader -->
        <!-- Begin Container -->
        <div class="container-fluid h-100 overflow-y">
            <div class="row flex-row h-100">
                <div class="col-12 my-auto">
                    <div class="password-form mx-auto">
                        <div class="logo-centered" style="text-align: center;font-size: 1.6em;color: #7dbb2a;margin-bottom: 33px;width:49%;">
                                YTLStore
                        </div>
                        <h3 style="color: #a75463;">Vendor Signup</h3>
                        <form method="post">
                            <div class="group material-input">
							    <input type="text" name="fname" required>
							    <span class="highlight"></span>
							    <span class="bar"></span>
							    <label>First Name</label>
                            </div>
                             <div class="group material-input">
							    <input type="text" name="lname" required>
							    <span class="highlight"></span>
							    <span class="bar"></span>
							    <label>Last Name</label>
                            </div>
                             <div class="group material-input">
							    <input type="email" name="email" required>
							    <span class="highlight"></span>
							    <span class="bar"></span>
							    <label>Email</label>
                            </div>
                            <div class="group material-input">
							    <input type="password" name="vpassword" required>
							    <span class="highlight"></span>
							    <span class="bar"></span>
							    <label>Password</label>
                            </div>
                            <div class="group material-input">
							    <input type="text" name="phonenumber" required>
							    <span class="highlight"></span>
							    <span class="bar"></span>
							    <label>Phone Number</label>
                            </div>
                        <div class="button text-center">
                            <button type="submit" name="adminlogin" class="btn btn-lg btn-gradient-01">
                                Submit
                            </button>
                        </div>
                       <a href="Login.php"><p style="margin: 18px 0 -42px 64px;">Already have an account? Login</p></a> 
                        </form>
                    </div>        
                </div>
                <!-- End Col -->
            </div>
            <!-- End Row -->
        </div>  
        <!-- End Container --> 
        <!-- Begin Vendor Js -->
        <script src="assets/vendors/js/base/jquery.min.js"></script>
        <script src="assets/vendors/js/base/core.min.js"></script>
        <!-- End Vendor Js -->
        <!-- Begin Page Vendor Js -->
        <script src="assets/vendors/js/app/app.min.js"></script>
        <!-- End Page Vendor Js -->
    </body>
</html>

<?php

if(isset($_REQUEST['adminlogin']))
{
  extract($_REQUEST);
  $query="select * from vendor_register where email='$email' or phonenumber='$phonenumber'";
  $res=mysqli_query($con,$query);
  $num=mysqli_num_rows($res);
  if($num>0){
        //  $_SESSION['username'] = $username;
    echo "<script>alert('Vendor Already Exist')</script>";
  }else{
     $string1 = str_shuffle('abcdefghijklmnopqrstuvwxyz1234567890');
    $random = substr($string1,0,6);
  $query1="INSERT INTO vendor_register value(NULL, '$fname', '$lname', '$email', '$vpassword', '$phonenumber', '$random', '', '', now())";
  $res1=mysqli_query($con,$query1);
  if($res1){
  	echo "<script>window.location='Login.php'</script>";
  }else{
  	echo "<script>alert('Login failed....')</script>";
  	echo "<script>window.location='Login.php'</script>";
  }
}
}
?>