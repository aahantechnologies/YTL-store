<!DOCTYPE html>
<!--
Item Name: Elisyam - Web App & Admin Dashboard Template
Version: 1.5
Author: SAEROX

** A license must be purchased in order to legally use this template for your project **
-->
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Complete Order</title>
        <meta name="description" content="CompleteOrder">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <script>
          WebFont.load({
            google: {"families":["Montserrat:400,500,600,700","Noto+Sans:400,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
        <!-- Stylesheet -->
        <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
        <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5.min.css">
        <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    </head>
            <!-- Begin Header -->
          <?php 
   include 'Header.php';
   ?>
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">
            <?php 
            include 'SideMenu.php';
            ?>
                <div class="content-inner">
                    <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Complete Order</h2>
	                                <div>
			                            <ul class="breadcrumb">
			                                <li class="breadcrumb-item"><a href="db-default.html"><i class="ti ti-home"></i></a></li>
			                                <li class="breadcrumb-item active">Complete Order</li>
			                            </ul>
	                                </div>
	                            </div>
                                <div class="widget-body">
                                        <div class="form-group">
                                            <!--<a href="AddProduct.php">  <button type="button" class="btn btn-primary mr-1 mb-2">Add Product</button></a>-->
                                           
                                        </div>
                                    </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>Detail</h4>
                                    </div>
                                    <div class="widget-body">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>User Name</th>
                                                        <th>Product Name</th>
                                                        <th>Product Image</th>
                                                        <th>Product Price</th>
														<th>Product Discount Price</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
 <?php
 include 'connection.php';
$query1="select * from orderdetail where status='4'";
$res1=mysqli_query($con,$query1);
while($row1=mysqli_fetch_array($res1))
{
?>                                                      <tr>
                                                        <td><span class="text-primary"><?php echo $row1['regid'];?></span></td>
                                                         <td><?php echo $row1['productname'];?></td>
                                                          <td><img src="../api/<?php echo $row1['image'];?>" height="70" width="70"></td>
                                                           <td>Rs. <?php echo $row1['realprice'];?></td>
                                                            <td>Rs. <?php echo $row1['offerprice'];?></td>
                                                            <td class="td-actions"> 
                                                            <a title='update record' href="ViewCompleteOrder.php?regid=<?php echo $row1['regid'];?>"><i class='la la-edit edit'></i> </a>
                       
                                                   
                      <a title='Delete record' href="CompleteOrder.php?regid=<?php echo $row1['regid'];?>">  <i class='la la-close delete'></i>
</a>
                                                        </td>
                                                        </tr>
<?php
}
?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->                              
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
                    <!-- Begin Page Footer-->
                   <?php
           include 'Footer.php';
           ?>
                    <!-- End Page Footer -->
                    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
                </div>
            </div>
            <!-- End Page Content -->
        </div>
        <!-- Begin Vendor Js -->
        <script src="assets/vendors/js/base/jquery.min.js"></script>
        <script src="assets/vendors/js/base/core.min.js"></script>
        <!-- End Vendor Js -->
        <!-- Begin Page Vendor Js -->
        <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
        <script src="assets/vendors/js/app/app.min.js"></script>
        <!-- End Page Vendor Js -->
    </body>
</html>
<?php
if(isset($_REQUEST['regid']))
{  
$regid=$_REQUEST['regid'];
  $query="delete from orderdetail where regid=$regid";
  if(mysqli_query($con,$query))
  {
   echo "<script>confirm('Are you sure...')</script>";
   echo "<script>alert('Record deleted...')</script>";
   echo "<script>window.location='CompleteOrder.php'</script>";
  }
  else
  {
  	 echo "<script>alert('Record not deleted...')</script>";
  	 echo "<script>window.location='CompleteOrder.php'</script>"; 
 }
}
?>
          