<?php
session_start();
unset($_SESSION['vemail']);
session_destroy();

header("Location: Login.php");
exit;
?>
