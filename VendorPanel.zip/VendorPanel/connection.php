<?php
   $con=mysqli_connect("aahantechnologies.com","raadh5xq","Random1234$#@!","raadh5xq_ytlstore") or die('problem in connection');
   
   ?>