    <div class="default-sidebar">
                    <!-- Begin Side Navbar -->
                    <nav class="side-navbar box-scroll sidebar-scroll">
                        <!-- Begin Main Navigation -->
                         <ul class="list-unstyled">
                            <li><a href="index.php"><i class="la la-puzzle-piece"></i><span>Dashboard</span></a></li>
                            <!--<li><a href="Product.php"><i class="la la-book"></i><span>Product</span></a><li>-->
                            <!--<li><a href="#dropdown-authentication" aria-expanded="false" data-toggle="collapse" class="collapsed"><i class="la la-credit-card"></i><span>Payments</span></a>-->
                            <!--    <ul id="dropdown-authentication" class="collapse list-unstyled pt-0">-->
                            <!--        <li><a href="HeatPay.php">Heat Payment</a></li>-->
                            <!--        <li><a href="ReservationPay.php">Reservation Payment</a></li>-->
                            <!--        <li><a href="OffersPay.php">Offers Payment</a></li>-->
                            <!--    </ul>-->
                            <!--</li>-->
                            
                            <!--<li><a href="User.php"><i class="la la-user"></i><span>User's</span></a></li>-->
                            <!--<li><a href="Vendor.php"><i class="la la-users"></i><span>Vendor's</span></a></li>-->
                            <!--<li><a href="Category.php"><i class="la la-dedent"></i><span>Category</span></a></li>-->
                            <!--<li><a href="SubCategory.php"><i class="la la-check-square-o"></i><span>Sub Category</span></a></li>-->
                            <!--     <li><a href="#dropdown-Work" aria-expanded="false" data-toggle="collapse" class="collapsed"><i class="la la-archive"></i><span>How it Work</span></a>-->
                            <!--    <ul id="dropdown-Work" class="collapse list-unstyled pt-0">-->
                            <!--        <li><a href="DayHIW.php">365 Days</a></li>-->
                            <!--        <li><a href="WeekHIW.php">52 Weeks</a></li>-->
                            <!--        <li><a href="MonthHIW.php">12 Months</a></li>-->
                            <!--    </ul>-->
                            <!--</li>-->
                            <li><a href="Product.php"><i class="la la-archive"></i><span>Product</span></a></li>
                            <!--<li><a href="#dropdown-authenticationgo" aria-expanded="false" data-toggle="collapse" class="collapsed"><i class="la la-cart-plus"></i><span>Order</span></a>-->
                            <!--    <ul id="dropdown-authenticationgo" class="collapse list-unstyled pt-0">-->
                            <!--        <li><a href="CompleteOrder.php">Completed Order </a></li>-->
                            <!--        <li><a href="UpcomingOrder.php">Upcoming Order </a></li>-->
                            <!--        <li><a href="CancelledOrder.php">Cancelled Order</a></li>-->
                            <!--    </ul>-->
                            <!--</li>-->
                            <!--<li><a href="HomePage.php"><i class="la la-check-square-o"></i><span>Home Page Banner</span></a></li>-->
                            <!--<li><a href="TodaysOffer.php"><i class="la la-spinner"></i><span>Today's Offers </span></a></li>-->
                            <li><a href="TermsCondition.php"><i class="la la-expeditedssl"></i><span>Term's & Conditions </span></a></li>
                            <li><a href="Privacy.php"><i class="la la-key"></i><span>Privacy Policy</span></a></li>
                            <!--<li><a href="Trainer.php"><i class="la la-list-alt"></i><span>All Trainer</span></a></li>-->
                            <li><a href="Support.php"><i class="la la-headphones"></i><span>Support</span></a></li>
                            <li><a href="ContactUs.php"><i class="la la-phone"></i><span>Contact Us</span></a></li>
                            <!--<li><a href="Featured.php"><i class="la la-leaf"></i><span>Featured Plan</span></a>-->
                             <!--<li><a href="Earning.php"><i class="la la-leaf"></i><span>Earnings</span></a>-->
                            <!--<li><a href="#dropdown-report" aria-expanded="false" data-toggle="collapse" class="collapsed">-->
                            <!--    <i class="la la-bug"></i><span>Report</span></a>-->
                            <!--    <ul id="dropdown-report" class="collapse list-unstyled pt-0">-->
                            <!--        <li><a href="Reports.php">Ads Report</a></li>-->
                            <!--        <li><a href="PostReports.php">Post Report</a></li>-->
                            <!--    </ul>-->
                            <!--</li>-->
                             <!--<li><a href="Reports.php"><i class="la la-bug"></i><span>Reports</span></a>-->
                             <li><a href="Logout.php"><i class="ti-power-off"></i><span>Logout</span></a>
                        </ul>   
                        <!-- End Main Navigation -->
                    </nav>
                    <!-- End Side Navbar -->
                </div>
                <!-- End Left Sidebar -->