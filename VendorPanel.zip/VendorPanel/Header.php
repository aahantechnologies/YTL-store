      
<?php
if(empty($_SESSION)) // if the session not yet started
  session_start();
$vendorid = $_SESSION['vendorid'];
// echo $vemail;
if(!isset($_SESSION['vendorid'])) { //if not yet logged in
  header("Location: Login.php");// send to login page
}
?>
         <body id="page-top">
        <!-- Begin Preloader -->
        <div id="preloader">
            <div class="canvas">
                <div style="color:#e5486d;font-size: 3.6em;">YTLStore</div>
                <div class="spinner"></div>   
            </div>
        </div>
        <!-- End Preloader -->
        <div class="page">
         <!-- Begin Header -->
            <header class="header">
                <nav class="navbar fixed-top">         
                    <!-- Begin Search Box-->
                    <div class="search-box">
                        <button class="dismiss"><i class="ion-close-round"></i></button>
                        <form id="searchForm" action="#" role="search">
                            <input type="search" placeholder="Search something ..." class="form-control">
                        </form>
                    </div>
                    <!-- End Search Box-->
                    <!-- Begin Topbar -->
                    <div class="navbar-holder d-flex align-items-center align-middle justify-content-between">
                        <!-- Begin Logo -->
                        <div class="navbar-header">
                            <a href="db-default.html" class="navbar-brand">
                                <div class="brand-image brand-big">
                                    <p  style="color:#e5486d;font-size: 1.6em;">YTLStore</p>
                                </div>
                                <div class="brand-image brand-small">
                                    <small style="color:#e5486d;">YTLStore</small>
                                </div>
                            </a>
                            <!-- Toggle Button -->
                            <a id="toggle-btn" href="#" class="menu-btn active">
                                <span></span>
                                <span></span>
                                <span></span>
                            </a>
                            <!-- End Toggle -->
                        </div>
                        <!-- End Logo -->
                        <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center pull-right">
                            
                            <!-- Begin Notifications -->
                            <!--<li class="nav-item dropdown"><a id="notifications" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link"><i class="la la-bell animated infinite swing"></i><span class="badge-pulse"></span></a>-->
                                <ul aria-labelledby="notifications" class="dropdown-menu notification">

                                </ul>
                            </li>
                            <!-- End Notifications -->
                           
                        </ul>
                    </div>
                    <!-- End Topbar -->
                </nav>
            </header>
            <!-- End Header -->