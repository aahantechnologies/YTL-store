<!DOCTYPE html>
<?php
$regid=$_REQUEST['regid'];
include("connection.php");
$query="select * from productdetail where regid=$regid";
$res=mysqli_query($con,$query);
$row=mysqli_fetch_array($res);
$category = $row['category'];
$subcategory = $row['subcategory'];
?>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Product Detail - Dashboard</title>
        <meta name="description" content="Product Detail - Dashboard">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <script>
          WebFont.load({
            google: {"families":["Montserrat:400,500,600,700","Noto+Sans:400,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
        <!-- Stylesheet -->
        <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
        <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.theme.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
$(document).ready(function(){
    $('#mycountry').on('change', function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'DropDownSelect.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#mystate').html(html);
                }
            }); 
        }else{
            $('#mystate').html('<option value="">Select Category first</option>');
        }
    });
});
</script>
        <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    </head>
   
   <?php 
   include 'Header.php';
   ?>
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">
            <?php 
            include 'SideMenu.php';
            ?>
                <div class="content-inner">
                    <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Update Product</h2>
	                            </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>Detail</h4>
                                    </div>
                                    <div class="widget-body">
                                        <div class="table-responsive">
                                             <form  method="post" enctype="multipart/form-data">     
                                        <input class="form-control" type="hidden" name="image_old"  value="<?php echo $row['image'];?>"  required>
                                        <input class="form-control" type="hidden" name="imagesec_old"  value="<?php echo $row['imagesec'];?>"  required>
                                        <input class="form-control" type="hidden" name="imagenext_old"  value="<?php echo $row['imagethird'];?>"  required>
                                        <input class="form-control" type="hidden" name="imagelast_old"  value="<?php echo $row['imagelast'];?>"  required>                                               
                                              <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Product Name</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="productname" value="<?php echo $row['productname'];?>" required>
									</div>							
								</div>  
									<div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Category</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
  <?php
 $query7="select * from categories where id='$category'";
$res7=mysqli_query($con,$query7);
$row7=mysqli_fetch_array($res7);
$query9="select * from categories where id='$subcategory'";
$res9=mysqli_query($con,$query9);
$row9=mysqli_fetch_array($res9);
?>
                             <select class="form-control" name="category" id="mycountry" >
                                            
                                    <option value="<?php echo $row7['id'];?>"><?php echo $row7['name'];?></option>
<?php 
    include_once 'dbConfig.php'; 
    $query3 = "SELECT * FROM categories where parent_id='0' ORDER BY name ASC"; 
    $result3 = $db->query($query3); 
    if($result3->num_rows > 0){ 
        while($row33 = $result3->fetch_assoc()){  
            echo '<option value="'.$row33['id'].'">'.$row33['name'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">make not available</option>'; 
    } 
    ?>
                                            
                                        </select>
									</div>							
								</div>    
                               	<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Subcategory</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <select class="form-control" name="subcategory" id="mystate" >
                                    <option value="<?php echo $row9['id'];?>"><?php echo $row9['name'];?></option>
                                  </select>
									</div>									
								</div> 
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Real Price</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="realprice" value="<?php echo $row['realprice'];?>" required>
									</div>							
								</div>  
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Offer Price</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="offerprice" value="<?php echo $row['offerprice'];?>" required>
									</div>							
								</div>  
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Vendor Price</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="vendorprice"  value="<?php echo $row['vendorprice'];?>"  required>
									</div>							
								</div>  
								 <div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Vendor Minimum Quantity</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="number" name="vendorquantity"  value="<?php echo $row['vendorquantity'];?>" required>
									</div>							
								</div> 
									<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Sort Description</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <textarea class="form-control" type="text" name="description" rows="10" cols="5" ><?php echo $row['description'];?></textarea>
									</div>									
								</div>
									<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Description</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <textarea class="form-control" type="text" name="metadescription" rows="10" cols="5" ><?php echo $row['metadescription'];?></textarea>
									</div>									
								</div> 
									<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Information</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <textarea class="form-control" type="text" name="information" rows="10" cols="5" ><?php echo $row['information'];?></textarea>
									</div>									
								</div> 
							
								<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Quantity</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="quantity" value="<?php echo $row['quantity'];?>" required>
									</div>									
								</div>        
								<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Product Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                    <a href="../api/<?php echo $row['image'];?>"  target="_blank"  ><img src="../api/<?php echo $row['image'];?>" height="70" width="70"></a> 
                                        <input type="file" class="form-control" name="image"  value="<?php echo $row['image'];?>" >
									</div>							
								</div>  
								<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Product Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                    <a href="../api/<?php echo $row['imagesec'];?>"  target="_blank"  ><img src="../api/<?php echo $row['imagesec'];?>" height="70" width="70"></a> 
                                        <input type="file" class="form-control" name="imagesec"  value="<?php echo $row['imagesec'];?>" >
									</div>							
								</div>   
								<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Product Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                    <a href="../api/<?php echo $row['imagethird'];?>"  target="_blank"  ><img src="../api/<?php echo $row['imagethird'];?>" height="70" width="70"></a> 
                                        <input type="file" class="form-control" name="imagenext"  value="<?php echo $row['imagethird'];?>" >
									</div>							
								</div> 
								<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Product Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                    <a href="../api/<?php echo $row['image'];?>"  target="_blank"  ><img src="../api/<?php echo $row['imagelast'];?>" height="70" width="70"></a> 
                                        <input type="file" class="form-control" name="imagelast"  value="<?php echo $row['imagelast'];?>" >
									</div>							
								</div> 
				            	
								<div class="form-group">							 
									<br/>								
								<div class="col-md-12 col-sm-12 col-xs-12">
								<center><input type="submit" class="btn btn-gradient-01" value="UPDATE" name="updatep"/></center>
								</div> </div> <br/>							 
									<br/>
                             <!--<button type="reset" class="btn btn-danger">Reset</button>-->
                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->                              
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
                    <?php 
                    include 'Footer.php';
                    ?>
                    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
                   
                </div>
                <!-- End Content -->
            </div>
            <!-- End Page Content -->
        </div>
        <!-- Begin Vendor Js -->
        <script src="assets/vendors/js/base/jquery.min.js"></script>
        <script src="assets/vendors/js/base/core.min.js"></script>
        <!-- End Vendor Js -->
        <!-- Begin Page Vendor Js -->
        <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
        <script src="assets/vendors/js/chart/chart.min.js"></script>
        <script src="assets/vendors/js/progress/circle-progress.min.js"></script>
        <script src="assets/vendors/js/calendar/moment.min.js"></script>
        <script src="assets/vendors/js/calendar/fullcalendar.min.js"></script>
        <script src="assets/vendors/js/owl-carousel/owl.carousel.min.js"></script>
        <script src="assets/vendors/js/app/app.js"></script>
        <!-- End Page Vendor Js -->
        <!-- Begin Page Snippets -->
        <script src="assets/js/dashboard/db-default.js"></script>
        <!-- End Page Snippets -->
    </body>
</html>

<?php
if(isset($_REQUEST['updatep']))
{  
     extract($_REQUEST);
    $filename=$_FILES['image']['name'];
    $tmpname=$_FILES['image']['tmp_name'];
     if($filename==''){
        $destination=$image_old;
    }else{
    $newfname=rand(111,111111).'-'.$filename;
	$destination="upload/$newfname";
    $destination1="../api/upload/$newfname";
    $res=move_uploaded_file($tmpname,$destination1);  
    }
    
    $filename1=$_FILES['imagesec']['name'];
    $tmpname1=$_FILES['imagesec']['tmp_name'];
     if($filename1==''){
        $destination2=$imagesec_old;
    }else{
    $newfname1=rand(111,111111).'-'.$filename1;
	$destination2="upload/$newfname1";
    $destination3="../api/upload/$newfname1";
    $res2=move_uploaded_file($tmpname1,$destination3); 
    }
    
    $filename2=$_FILES['imagenext']['name'];
    $tmpname2=$_FILES['imagenext']['tmp_name'];
     if($filename2==''){
        $destination4=$imagenext_old;
    }else{
    $newfname2=rand(111,111111).'-'.$filename2;
	$destination4="upload/$newfname2";
    $destination5="../api/upload/$newfname2";
    $res3=move_uploaded_file($tmpname2,$destination5); 
    }
    
     $filename3=$_FILES['imagelast']['name'];
    $tmpname3=$_FILES['imagelast']['tmp_name'];
     if($filename3==''){
        $destination6=$imagelast_old;
    }else{
    $newfname3=rand(111,111111).'-'.$filename3;
	$destination6="upload/$newfname3";
    $destination7="../api/upload/$newfname3";
    $res4=move_uploaded_file($tmpname3,$destination7); 
    }
    // metadescription
    $firstname = mysqli_real_escape_string($con, $description);
    $metago = mysqli_real_escape_string($con, $metadescription);
    $infoget = mysqli_real_escape_string($con, $information);
    
    $query="update productdetail set brand='$brand',quantity='$quantity',vendorquantity='$vendorquantity',vendorprice='$vendorprice', offerprice='$offerprice',realprice='$realprice', description='$firstname',gosize='$gosize',information='$infoget',description='$firstname', metadescription='$metadescription',imagesec='$destination2',imagethird='$destination4',imagelast='$destination6',productname='$productname',category='$category',subcategory='$subcategory' where regid=$regid";
     $res1=mysqli_query($con,$query);     
    if($res1)
    {        
        echo "<script>window.location='Product.php'</script>";
    }
 else {        
        echo "<script> alert('Failed')</script>";
        echo "<script>window.location='EditProduct.php?regid=$regid'</script>";     
      }
}
?>