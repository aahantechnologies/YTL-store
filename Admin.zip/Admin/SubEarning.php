<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>FillNFull - Dashboard</title>
        <meta name="description" content="EAT OR TAKE - Dashboard">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
        <script src="//code.jquery.com/jquery-1.10.2.js"></script>
        <script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
         
        <script language="javascript" type="text/javascript">
            $(function() {
            var availableTags = <?php echo json_encode($response); ?>;
            $( "#mygotags" ).autocomplete({
            source: availableTags,
             select: function(event, ui) {
        // Retrieve your id here and do something with it.
          console.log(ui.item.label);
          var email=ui.item.label;
          document.getElementById("hidden1").value = email;
          document.getElementById("goform").submit();
          }
            });
            });
        </script>
      
        <script>
          WebFont.load({
            google: {"families":["Montserrat:400,500,600,700","Noto+Sans:400,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <script type="text/javascript">
   	var ctx = document.getElementById("orders").getContext('2d');
	var myChart = new Chart(ctx, {
		type: 'roundedBar',
		data: {
			labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
			datasets: [{
				label: 'Delivered',
				data: [30, 24, 22, 17, 22, 24, 9, 14, 20, 13, 17, 13],
				borderColor: "#fff",
				backgroundColor: "#5d5386",
				hoverBackgroundColor: "#483d77"
			}, 
// 			{
// 				label: 'Estimated',
// 				data: [10, 14, 12, 20, 20, 8, 10, 20, 7, 11, 8, 10],
// 				borderColor: "#fff",
// 				backgroundColor: "#e4e8f0",
// 				hoverBackgroundColor: "#dde1e9"
// 			}
			]
		},
		options: {
			responsive: true,
			barRoundness: 1,
			tooltips: {
				backgroundColor: 'rgba(47, 49, 66, 0.8)',
				titleFontSize: 13,
				titleFontColor: '#fff',
				caretSize: 0,
				cornerRadius: 4,
				xPadding: 5,
				displayColors: false,
				yPadding: 5,
			},
			legend: {
				display: true,
				position: 'bottom',
				labels: {
					fontColor: "#2e3451",
					usePointStyle: true,
					padding: 50,
					fontSize: 13
				}
			},
			scales: {
				xAxes: [{
					barThickness: 20,
					stacked: false,
					gridLines: {
						drawBorder: false,
						display: false
					},
					ticks: {
						display: true
					}
				}],
				yAxes: [{
					stacked: false,
					gridLines: {
						drawBorder: false,
						display: false
					},
					ticks: {
						display: false
					}
				}]
			}
		}
	});
   </script>
        <!-- Favicon -->
        <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">-->
        <!--<link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">-->
        <!--<link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">-->
        <!-- Stylesheet -->
        <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
        <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.theme.min.css">
        <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    </head>
 <?php
require "connection.php";
$sqlquery ="SELECT SUM(price) as firstm FROM subpayment WHERE curdate > DATE_SUB(NOW(), INTERVAL 1 MONTH) ORDER BY regid DESC ";
$res = mysqli_query($con, $sqlquery);
$row=mysqli_fetch_array($res);
?>
   
   <?php 
   include 'Header.php';
   ?>
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">
            <?php 
            include 'SideMenu.php';
            ?>  <div class="content-inner">
                 <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Subscription Earning</h2>
	                                <div>
	                                <div class="page-header-tools">
	                                    <!--<a class="btn btn-gradient-01" href="#">Add Widget</a>-->
	                                </div>
	                                </div>
	                            </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        <!-- Begin Row -->
                        <?php
require "connection.php";
$sqlquery ="SELECT SUM(price) as Total FROM featurepay WHERE curdate > DATE_SUB(NOW(), INTERVAL 1 DAY) ORDER BY regid DESC; ";
$res = mysqli_query($con, $sqlquery);
$row=mysqli_fetch_array($res);
$sql ="SELECT SUM(price) as sumdata FROM featurepay";
$result = mysqli_query($con, $sql);
$row1=mysqli_fetch_array($result);
?>
                        <div class="row flex-row">
                            <!-- Begin Facebook -->
                            <div class="col-xl-6 col-md-6 col-sm-6">
                                <div class="widget widget-12 has-shadow">
                                    <div class="widget-body">
                                        <div class="media">
                                            <div class="media-body text-center">
                                                <div class="title text-twitter">Today Earning</div>
                                                <div class="number" style="font-size: 2rem;margin: 11px 0 0 0;">&#8377;<?php
                                                if($row['Total']==''){
                                                echo '0';
                                                }
                                                else{
                                                echo $row['Total'];
                                                }?></div>
<?php
// $today=date('d F Y');
// $todaysmonth = date('n', strtotime($today));
// for($i = $todaysmonth; $i <= 12; $i++){
//     $dateObj   = DateTime::createFromFormat('!m', $i);
//     echo $monthName = $dateObj->format('M');
//      echo $monthName[0];
// }
 ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Facebook -->
                            <!-- Begin Twitter -->
                            <div class="col-xl-6 col-md-6 col-sm-6">
                                <div class="widget widget-12 has-shadow">
                                    <div class="widget-body">
                                        <div class="media">
                                            <div class="media-body text-center">
                                                <div class="title text-twitter">Total Earning</div>
                                                <div class="number" style="font-size: 2rem;margin: 11px 0 0 0;">&#8377;<?php echo $row1['sumdata'] ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Twitter -->
                            
                        </div>
                        <!-- End Row -->
                        <!-- Begin Row -->
                       <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>Detail</h4>
                                    </div>
                                    <div class="widget-body">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Price</th>
                                                        <th>Title</th>
                                                        <th>Category</th>
                                                        <th>Sub Category</th>
                                                        <th>Day</th>
                                                        <!--<th>Payment Id</th>-->
														<th>Expiry Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                           
<?php  
 include 'connection.php';
$query1="select * from featurepay ORDER BY regid DESC";
$res1=mysqli_query($con,$query1);
$i=1;
$count = mysqli_num_rows($res1);
while($row1=mysqli_fetch_array($res1))
{
    $status= $row1['status'];
    $email= $row1['email'];
    $title= $row1['title'];
    $query2="select * from register where email='$email'";
    $res2=mysqli_query($con,$query2);
    $row2=mysqli_fetch_array($res2);
    $query3="select * from postads where email='$email' and title='$title'";
    $res3=mysqli_query($con,$query3);
    $row3=mysqli_fetch_array($res3);
?>                                                      <tr>
                                                        <td><span class="text-primary"><?php echo $i;?></span></td>
                                                        <td><?php echo $row2['firstname'];?> <?php echo $row2['lastname'];?></td>
                                                        <td><?php echo $row1['email'];?></td>
                                                        <td><?php echo $row1['price'];?></td>
                                                        <td><?php echo $row1['title'];?></td>
                                                         <td><?php echo $row3['category'];?></td>
                                                          <td><?php echo $row3['subcategory'];?></td>
                                                        <td><?php echo $row1['day'];?></td>
                                                        <!--<td><?php echo $row1['paymentid'];?> </td>-->
                                                        <td><?php echo $row1['expirydate'];?> </td>
                                                        </tr>
<?php
$i++;
}
?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->                              
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
                   <?php 
                    include 'Footer.php';
                    ?>
                    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
                   
                </div>
                <!-- End Content -->
            </div>
            <!-- End Page Content -->
        </div>
        <!-- Begin Vendor Js -->
        <!--<script src="assets/vendors/js/base/jquery.min.js"></script>-->
          <script>
          function myFunction(gender) {
          document.getElementById("hidden1").value = gender;
          document.getElementById("goform").submit();
         }
        </script>
        
        <script src="assets/vendors/js/base/core.min.js"></script>
        <!-- End Vendor Js -->
        <!-- Begin Page Vendor Js -->
        <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
        <script src="assets/vendors/js/chart/chart.min.js"></script>
        <script src="assets/vendors/js/progress/circle-progress.min.js"></script>
        <script src="assets/vendors/js/calendar/moment.min.js"></script>
        <script src="assets/vendors/js/calendar/fullcalendar.min.js"></script>
        <script src="assets/vendors/js/owl-carousel/owl.carousel.min.js"></script>
        <script src="assets/vendors/js/app/app.js"></script>
        <!-- End Page Vendor Js -->
        <!-- Begin Page Snippets -->
        <script src="assets/js/dashboard/indexnew.js"></script>
        <!-- End Page Snippets -->
    </body>
</html>