<?php 
// Include the database config file 
 include_once 'dbConfig.php'; 
 
if(!empty($_POST["country_id"])){ 
    // Fetch state data based on the specific country 
    $CID = $_POST["country_id"];
    $query = "SELECT * FROM categories WHERE parent_id =$CID"; 
    $result = $db->query($query); 
     
    // Generate HTML of state options list 
    if($result->num_rows > 0){ 
        echo '<option value="">Select Sub Category</option>'; 
        while($row = $result->fetch_assoc()){  
            echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">Sub Category not available</option>'; 
    } 
}
?>