<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>FillNFull - </title>
        <meta name="description" content="Elisyam is a Web App and Admin Dashboard Template built with Bootstrap 4">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <script>
          WebFont.load({
            google: {"families":["Montserrat:400,500,600,700","Noto+Sans:400,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
        <!-- Stylesheet -->
        <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
        <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl-carousel/owl.theme.min.css">
    </head>
   
   <?php 
   include 'Header.php';
   ?>
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">
            <?php 
            include 'SideMenu.php';
            ?>
                <div class="content-inner">
                    <div class="container-fluid">
                        <!-- Begin Page Header-->
                        <div class="row">
                            <div class="page-header">
	                            <div class="d-flex align-items-center">
	                                <h2 class="page-header-title">Add Post</h2>
	                            </div>
                            </div>
                        </div>
                        <!-- End Page Header -->
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <!-- Default -->
                                <div class="widget has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>Detail</h4>
                                    </div>
                                    <div class="widget-body">
                              <div class="table-responsive">
                                <form  method="post" enctype="multipart/form-data">                                                    
                                  <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Title</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="title"  required>
									</div>							
								</div>  
								<div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Subject</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <select class="form-control" type="text" name="subject"  required>
                                          <option value="New">New</option>
                                          <option value="Used">Used</option>
                                          <option value="Sell">Sell</option>
                                          <option value="Buy">Buy</option>
                                          <option value="Rent">Rent</option>
                                          <option value="Lease">Lease</option>
                                          <option value="Service">Service</option>
                                          <option value="Others">Others</option>
                                        </select>
									</div>							
								</div>                                                  		
                               	<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Description</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <textarea class="form-control" type="text" name="description" required></textarea>
									</div>									
								</div> 
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Price</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="price"  required>
									</div>							
								</div>   
									<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Address</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <textarea class="form-control" type="text" name="address" required></textarea>
									</div>									
								</div> 
								<div class="form-group">
								<label class="control-label col-md-2 col-sm-2 col-xs-12">Category Name</label>
                                <div class="col-md-8 col-sm-4 col-xs-12">
                                <select class="form-control" name="category">
<?php
include("connection.php");
$query="select * from categories where parent_id=0";
$res=mysqli_query($con,$query);
while($row=mysqli_fetch_array($res)){
?>
                                             <option> <?php echo $row['name'] ;?></option>
                                             <?php
}
?>
                                        </select>
									</div>
									</div> 
                                    <div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Sub Category Name</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                         <select class="form-control" name="subcategory">
<?php
include("connection.php");
$query="select * from categories where parent_id!=0";
$res=mysqli_query($con,$query);
while($row=mysqli_fetch_array($res)){
?>
                                             <option> <?php echo $row['name'] ;?></option>
                                             <?php
}
?>
                                        </select>
									</div>
								</div>  
								<!-- <div class="form-group">-->
								<!--	<label class="control-label col-md-6 col-sm-6 col-xs-12">Radius (In KM)</label>-->
        <!--                            <div class="col-md-8 col-sm-4 col-xs-12">-->
        <!--                                <input class="form-control" type="text" name="radius" required>-->
								<!--	</div>									-->
								<!--</div> -->
								<div class="form-group">
									<label class="control-label col-md-6 col-sm-6 col-xs-12">Email</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="text" name="email" required>
									</div>									
								</div>     
								
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="file" name="image"  required>
									</div>							
								</div> 
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Second Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="file" name="imagesec"  required>
									</div>							
								</div>
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12">Third Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="file" name="imagenext"  required>
									</div>							
								</div>
								 <div class="form-group">
									<label class="control-label col-md-2 col-sm-2 col-xs-12"> Fourth Image</label>
                                    <div class="col-md-8 col-sm-4 col-xs-12">
                                        <input class="form-control" type="file" name="imagelast"  required>
									</div>							
								</div>
        						 <div class="form-group">	
        							 <div class="col-md-12 col-sm-12 col-xs-12">
        							 <center>
        							 <input type="submit" class="btn btn-gradient-01" value="Add" name="updatep"/>
        						 </center>
        						 	</div>
        						 	</div> 
        								<br/>							 
        							 <br/>
                                    </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Default -->                              
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Container -->
                    <?php 
                    include 'Footer.php';
                    ?>
                    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
                   
                </div>
                <!-- End Content -->
            </div>
            <!-- End Page Content -->
        </div>
        <!-- Begin Vendor Js -->
        <script src="assets/vendors/js/base/jquery.min.js"></script>
        <script src="assets/vendors/js/base/core.min.js"></script>
        <!-- End Vendor Js -->
        <!-- Begin Page Vendor Js -->
        <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
        <script src="assets/vendors/js/chart/chart.min.js"></script>
        <script src="assets/vendors/js/progress/circle-progress.min.js"></script>
        <script src="assets/vendors/js/calendar/moment.min.js"></script>
        <script src="assets/vendors/js/calendar/fullcalendar.min.js"></script>
        <script src="assets/vendors/js/owl-carousel/owl.carousel.min.js"></script>
        <script src="assets/vendors/js/app/app.js"></script>
        <!-- End Page Vendor Js -->
        <!-- Begin Page Snippets -->
        <script src="assets/js/dashboard/db-default.js"></script>
        <!-- End Page Snippets -->
    </body>
</html>

<?php
include 'connection.php';
if(isset($_REQUEST['updatep']))
{  
    extract($_REQUEST);
    $filename=$_FILES['image']['name'];
    $tmpname=$_FILES['image']['tmp_name'];
    $newfname=rand(111,111111).'-'.$filename;
	$destination="upload/$newfname";
    $destination1="../api/upload/$newfname";
    $res=move_uploaded_file($tmpname,$destination1);  
    
    $filename1=$_FILES['imagesec']['name'];
    $tmpname1=$_FILES['imagesec']['tmp_name'];
    $newfname1=rand(111,111111).'-'.$filename1;
	$destination2="upload/$newfname1";
    $destination3="../api/upload/$newfname1";
    $res2=move_uploaded_file($tmpname1,$destination3); 
    
    $filename2=$_FILES['imagenext']['name'];
    $tmpname2=$_FILES['imagenext']['tmp_name'];
    $newfname2=rand(111,111111).'-'.$filename2;
	$destination4="upload/$newfname2";
    $destination5="../api/upload/$newfname2";
    $res3=move_uploaded_file($tmpname2,$destination5); 
    
     $filename3=$_FILES['imagelast']['name'];
    $tmpname3=$_FILES['imagelast']['tmp_name'];
    $newfname3=rand(111,111111).'-'.$filename3;
	$destination6="upload/$newfname3";
    $destination7="../api/upload/$newfname3";
    $res4=move_uploaded_file($tmpname3,$destination7); 
    
    $query="insert into postads values (NULL,'$destination','$destination2','$destination4','$destination6','$title','$subject','$description', '$price','$useradd','$address','','$category','$subcategory','$radius','$email', now(),'Approve','','')";
     $res1=mysqli_query($con,$query);     
    if($res1 && $res)
    {        
        echo "<script>window.location='AdsPost.php'</script>";
    }
 else {        
        echo "<script> alert('Failed')</script>";
        echo "<script>window.location='AddAdsPost.php'</script>";     
      }
}
?>